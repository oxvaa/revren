# REVREN 1.0 — Expo SDK 58

Native React Native application for car culture. English is always the first-launch default; Czech can be selected in **You → Settings → Language → CS** and persists across restarts.

## Run

Requires Node.js LTS and Expo Go with SDK 58 support.

```sh
npm ci
npm start
```

Scan the QR in Expo Go (iPhone: Camera → Expo Go). The phone and development host need network connectivity. If LAN is unavailable, use an authenticated Expo tunnel:

```sh
npx expo login
npx expo start --tunnel
```

Expo CLI also offers `npx expo start --tunnel ngrok`. Availability depends on the host network. A live development server is required; this ZIP is a source project, not an installable IPA/APK or a permanently hosted QR link.

No Apple Developer subscription is needed to test supported features inside Expo Go. Standalone builds and store distribution are separate work.

## EAS Update

Expo project: https://expo.dev/accounts/jipo7973/projects/revren

Project ID: `4e049bdb-725e-4d8e-91f1-4b38444886b2`. This project uses SDK 58 and the SDK runtime policy, which resolves to `exposdk:58.0.0`. No standalone native build is required to preview supported features in a matching Expo Go installation.

After logging into EAS as `jipo7973`, publish with:

```sh
npx eas-cli@27.1.0 login --device
npm run publish:preview
```

The command publishes the iOS and Android bundles to the `preview` branch using the `preview` environment. It does not start an EAS Build job. Open the resulting update from the Expo dashboard or Expo Go while signed into the owning account. Native dependencies must remain supported by Expo Go for SDK 58.

## What works

- Discover: bundled editorial photography, meet cards, local likes and bookmarks.
- Garage: add/edit/delete cars, choose a photo, model year, horsepower, color, modifications.
- Meets: create/edit/delete personal meet plans, search, filter, save, add to plans, share text, open location in Maps.
- Native map with concept-meet pins. User-created places open by name in Apple/Google Maps; there is no geocoder or GPS collection.
- Crews: create local workspaces with persistent notes.
- Profile: display name/city, English/Czech switch, optional haptics, JSON text export without photos.
- Persistent local storage; native photos copied into the app document directory. Bundled images work offline.
- Reduced-motion support, keyboard avoidance, safe areas, accessible control labels.

## Scope

This is a functional local-first first release, not a connected social network. No accounts, backend, public event publishing, real member directory, push notifications, or cross-device group chat have been connected. Crews contain a local notebook, not simulated replies. Two clearly labelled concept meets are inspiration only and cannot be RSVP'd. Personal plans and saved items are not sent to anyone automatically.

Data lives in AsyncStorage under `revren.v1`; deleting the app can remove it. It is not encrypted. Photo paths are local and excluded from text exports. Removed photos may remain in the app document directory until app data is cleared; this preserves safety when editing/reusing photos.

## Phone-only workflow

The accompanying `REVREN-preview.html` runs the same application through React Native Web, with embedded scripts, photos and icon font. It is a preview, not Expo Go. It can be opened in a browser that supports HTML apps.

For native testing without a PC, the source can be run on an online Node.js development host (for example an existing Codespace), with an Expo tunnel. The Snack SDK package available during creation reported support only through SDK 54, so no unverified SDK 58 Snack link was generated and the project was not downgraded.

## Validation

```sh
npm test
npx expo install --check
npx expo-doctor
npx expo export --platform all
```

During creation: model/translation checks, browser interaction flows and iOS/Android/Web bundling were performed. A physical iPhone was not available; native photo permissions, haptics, map rendering and share-sheet presentation still require device testing.

## Photos

Bundled editorial images from Unsplash:
- https://images.unsplash.com/photo-1503376780353-7e6692767b70
- https://images.unsplash.com/photo-1555215695-3004980ad54e
- https://images.unsplash.com/photo-1519681393784-d120267933ba
- https://images.unsplash.com/photo-1492144534655-ae79c964c9d7

Photos are editorial inspiration, not claimed user vehicles or documentation of actual events. REVREN name/trademark availability has not been researched.
