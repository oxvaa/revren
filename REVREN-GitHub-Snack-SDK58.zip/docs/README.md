# REVREN GitHub → Snack launcher

GitHub Pages should publish the `/docs` folder from `main`.

Open the published index.html, then choose **Open REVREN in Snack**. The launcher supplies:
- `sdkVersion=58.0.0`
- a public `sourceUrl` to `App.snack.js` on the same GitHub Pages site
- the native dependency versions from `snack-config.json`

`App.snack.js` contains the full application, translations, local model, and all four photos as data URIs. No relative project imports are required. Regenerate it after changing native source with `node scripts/build-snack.cjs`.

This launcher requests SDK 58; it does not override Snack's available runtimes. If Snack reports a downgrade, do not use that session for SDK 58 testing. The packaged `preview.html` is a separate browser preview, not Expo Go.

Repository: https://github.com/oxvaa/revren. Source upload and GitHub Pages publication are pending.
