export const STORAGE_KEY = 'revren.v1';
export const emptyState = {version:1, lang:'en', name:'Driver', city:'Ostrava', cars:[], meets:[], crews:[], saved:[], joined:[], likes:[], haptics:true};
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2,8);
export const toggle = (items, id) => items.includes(id) ? items.filter(x=>x!==id) : [...items,id];
export function hydrate(raw) {
  if (!raw || raw.version !== 1) return {...emptyState};
  const next={...emptyState,...raw,lang:raw.lang==='cs'?'cs':'en'};
  for (const key of ['cars','meets','crews','saved','joined','likes']) if(!Array.isArray(next[key])) next[key]=[];
  return next;
}
export function validate(kind, values) {
  if(kind==='car') return !values.make?.trim()||!values.model?.trim()?'required':(!/^\d{4}$/.test(values.year)||Number(values.year)<1900||Number(values.year)>new Date().getFullYear()+2)?'yearError':values.power&&(!/^\d+$/.test(values.power)||Number(values.power)>3000)?'powerError':null;
  if(kind==='meet') {
    if(!values.title?.trim()||!values.location?.trim()||!values.city?.trim()) return 'required';
    const date=new Date(values.date+'T'+values.time+':00');
    if(!/^\d{4}-\d{2}-\d{2}$/.test(values.date)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(values.time)||Number.isNaN(date.getTime())||date.getFullYear()!==Number(values.date.slice(0,4))||date.getMonth()+1!==Number(values.date.slice(5,7))||date.getDate()!==Number(values.date.slice(8,10))||date<=new Date()) return 'dateError';
  }
  if(kind==='crew'&&!values.title?.trim()) return 'required';
  if(kind==='profile'&&!values.name?.trim()) return 'required';
  return null;
}
